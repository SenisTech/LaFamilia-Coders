#!/usr/bin/env python3
"""Build data/<city>.json for every city in cities.json that has a feed.
A feed is taken from feeds/<id>.zip if present, otherwise downloaded from the
city's "url" (if any). Cities with no usable feed are skipped and never appear in the app.
Usage: python3 build_data.py [city-id ...]"""
import collections, csv, io, json, os, sys, urllib.request, zipfile

def open_zip(c):
    f = c.get("file")
    if f and os.path.exists(f):
        return zipfile.ZipFile(f)
    if c.get("url"):
        req = urllib.request.Request(c["url"], headers={"User-Agent": "transit-map/0.2"})
        return zipfile.ZipFile(io.BytesIO(urllib.request.urlopen(req, timeout=180).read()))
    return None

def build(z):
    def rows(name):
        with z.open(name) as fh:
            yield from csv.DictReader(io.TextIOWrapper(fh, encoding="utf-8-sig"))
    routes = {r["route_id"]: r for r in rows("routes.txt")}
    stops = {s["stop_id"]: s for s in rows("stops.txt")}
    trips, count = {}, collections.Counter()
    for t in rows("trips.txt"):
        k = (t["route_id"], t.get("direction_id") or "0", t.get("shape_id", ""))
        trips[t["trip_id"]] = k
        count[k] += 1
    best = {}
    for k, n in count.items():
        rd = (k[0], k[1])
        if rd not in best or n > count[best[rd]]:
            best[rd] = k
    wanted = set(best.values())
    rep = {}
    for tid, k in trips.items():
        if k in wanted and k not in rep:
            rep[k] = tid
    by_trip = {v: k for k, v in rep.items()}
    seq = collections.defaultdict(list)
    for st in rows("stop_times.txt"):
        k = by_trip.get(st["trip_id"])
        if k:
            seq[k].append((int(st["stop_sequence"]), st["stop_id"]))
    sh = {k[2] for k in wanted if k[2]}
    pts = collections.defaultdict(list)
    if "shapes.txt" in z.namelist():
        for p in rows("shapes.txt"):
            if p["shape_id"] in sh:
                pts[p["shape_id"]].append((int(p["shape_pt_sequence"]), float(p["shape_pt_lat"]), float(p["shape_pt_lon"])))
    out = []
    for k in sorted(wanted):
        r = routes[k[0]]
        ss = [[stops[i]["stop_name"], round(float(stops[i]["stop_lat"]), 5), round(float(stops[i]["stop_lon"]), 5)]
              for _, i in sorted(seq[k]) if i in stops]
        if not ss:
            continue
        line = [[round(a, 5), round(b, 5)] for _, a, b in sorted(pts.get(k[2], []))] or [[s[1], s[2]] for s in ss]
        name = (r.get("route_short_name") or r.get("route_long_name") or r["route_id"]).strip()
        out.append({"id": r["route_id"], "name": name, "long": r.get("route_long_name", ""),
                    "type": int(r.get("route_type") or 3), "color": "#" + (r.get("route_color") or "666666"),
                    "dir": k[1], "line": line, "stops": ss})
    return out

cities = json.load(open("cities.json", encoding="utf-8"))
only = set(sys.argv[1:])
os.makedirs("data", exist_ok=True)
built = []
for c in cities:
    if only and c["id"] not in only:
        if os.path.exists(f"data/{c['id']}.json"): built.append(c)
        continue
    try:
        z = open_zip(c)
        if z is None:
            print(f"- {c['id']}: no feed yet, skipped"); continue
        data = build(z)
        if not data:
            print(f"- {c['id']}: feed had no usable routes, skipped"); continue
        json.dump(data, open(f"data/{c['id']}.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
        built.append(c); print(f"+ {c['id']}: {len(data)} route directions")
    except Exception as e:
        print(f"- {c['id']}: failed ({e}), skipped")
index = [{"id": c["id"], "name": c["name"], "center": c["center"], "zoom": c.get("zoom", 12),
          "kind": c.get("kind", "city"), "live": bool(c.get("realtime"))} for c in built]
json.dump(index, open("data/index.json", "w", encoding="utf-8"), ensure_ascii=False)
print(f"data/index.json: {len(index)} datasets available")
